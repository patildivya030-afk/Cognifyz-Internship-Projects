"use strict";
require("./lib/env").loadEnv();
const { createApp } = require("./app");

const PORT = Number(process.env.PORT) || 3000;

createApp()
  .then(app => {
    const server = app.listen(PORT, () => {
      console.log(`CareerConnect Pro running at http://localhost:${PORT}`);
    });
    server.on("error", error => {
      if (error.code === "EADDRINUSE") console.error(`Port ${PORT} is already in use. Stop the other process or set PORT in .env.`);
      else console.error(error);
      process.exit(1);
    });
    const shutdown = () => server.close(() => process.exit(0));
    process.on("SIGINT", shutdown);
    process.on("SIGTERM", shutdown);
  })
  .catch(error => {
    console.error(error.message);
    process.exit(1);
  });
