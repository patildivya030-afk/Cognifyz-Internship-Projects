# CareerConnect Pro

A responsive internship and early-career portal built with **Node.js, Express 5, EJS and vanilla JavaScript**.
Candidates browse and search roles, save them, apply with a short note and track the status of each
application. Admins publish and remove roles and move applications through the hiring pipeline. Everything is
also available through a small REST API.

The only runtime dependencies are `express` and `ejs`. Password hashing, sessions, CSRF protection, rate
limiting and security headers are implemented with Node's built-in `crypto`, so there is nothing extra to install.

## Quick start

Requires **Node.js 18.18 or newer** (Node 22 recommended).

```bash
npm install        # optional - node_modules is already included in this ZIP
npm start
```

Open <http://localhost:3000>.

* **Windows:** double-click `START-WINDOWS.bat` (or run `npm.cmd start` if PowerShell blocks `npm.ps1`).
* **macOS / Linux:** `./start.sh`
* **Development with auto-restart:** `npm run dev`
* **Run the test-suite:** `npm test`

### Demo admin (development only)

| Email | Password |
|---|---|
| `admin@careerconnect.demo` | `Admin@12345` |

Candidates register themselves at `/register`. The demo admin exists only while `NODE_ENV` is not `production`
(see [Configuration](#configuration)).

## Features

**Candidates**
- Search roles by title, company, skill or location; filter by field. Search and filter combine and are kept in the URL.
- Register / log in with inline validation and a live password-strength meter. After logging in you return to the page you were trying to open.
- Save and unsave roles (instant, no page reload).
- Apply with an optional note (600 characters, live counter); duplicate applications are blocked; withdraw an application at any time.
- "My applications" shows a colour-coded status for each application.
- Profile page: change display name and password (changing the password signs out every other session).

**Admins**
- Publish roles with full server-side validation (errors are shown next to the fields and your input is kept).
- Remove roles (their applications and saved entries are cleaned up as well).
- Change an application's status: *Under review → Shortlisted → Interview scheduled → Offer extended / Not selected*.

**REST API** — see [below](#rest-api).

## Pages

| Route | Access | Purpose |
|---|---|---|
| `/` and `/internships` | public | Opportunity board with search and filters (`?q=java&category=Engineering`) |
| `/register`, `/login` | public | Create an account / sign in |
| `/applications` | candidate | Your applications and their status |
| `/saved` | candidate | Saved roles |
| `/profile` | signed in | Account details, change name / password |
| `/admin` | admin | Publish roles, manage applications |

## REST API

Responses are JSON. Writes must be sent with `Content-Type: application/json`. Authentication uses the same
session cookie as the website, so sign in first (browser, or `curl -c`/`-b` with a cookie jar).

| Method & path | Access | Description |
|---|---|---|
| `GET /api/health` | public | Liveness check |
| `GET /api/internships` | public | List. Optional `q`, `category`, `featured=true`. Cached for 15 s (`X-Cache: HIT/MISS`) |
| `GET /api/internships/:id` | public | One role |
| `POST /api/internships` | admin | Create (`title, company, category, location, stipend, duration, description`, optional `skills[]`, `level`, `featured`) |
| `PUT /api/internships/:id` | admin | Update any subset of those fields |
| `DELETE /api/internships/:id` | admin | Delete (204) |
| `GET /api/applications` | signed in | Your applications (admins see all) |
| `POST /api/applications` | candidate | `{ "internshipId": "...", "cover": "optional note" }` |
| `PATCH /api/applications/:id` | admin | `{ "status": "Shortlisted" }` |
| `DELETE /api/applications/:id` | owner / admin | Withdraw (204) |
| `GET /api/saved` | signed in | Your saved roles |

Status codes: `200/201/204` success · `400` malformed JSON · `401` not signed in · `403` not allowed ·
`404` not found · `409` already applied · `415` body not JSON · `422` validation failed (field errors in `fields`).

## Configuration

Copy `.env.example` to `.env` (optional in development).

| Variable | Default | Notes |
|---|---|---|
| `PORT` | `3000` | |
| `NODE_ENV` | – | Set to `production` for deployment |
| `SESSION_SECRET` | random per run | **Required in production** (32+ characters). The app refuses to start without it |
| `ADMIN_EMAIL`, `ADMIN_PASSWORD` | demo account | **Required in production** – no default admin is created there |
| `DATA_FILE` | `data/store.json` | Where data is stored |
| `AUTH_RATE_LIMIT` | `10` | Failed logins / registrations per IP per 15 min |
| `TRUST_PROXY` | – | Set to `true` behind a reverse proxy |

## Project structure

```
server.js            entry point (starts the HTTP server)
app.js               builds the Express app: middleware order, locals, error handling
lib/
  store.js           JSON data store (atomic writes, recovers from a corrupt file)
  security.js        scrypt hashing, sessions, CSRF/Origin checks, rate limiter, security headers
  guards.js          requireAuth / requireAdmin, safe redirects
  validate.js        validation rules shared by forms and the API
  seed.js, format.js, env.js
routes/              pages · auth (+profile) · applications (+saved) · admin · api
views/               EJS templates (partials/ holds header, footer, apply modal)
public/              css/style.css and js/app.js
test/app.test.js     36 tests (node:test, no extra packages)
data/                store.json is created here on first run
```

## Security notes

- Passwords are hashed with **scrypt** and a per-user salt; login takes the same time whether or not the email exists.
- Sessions are server-side, signed, `HttpOnly`, `SameSite=Lax` (and `Secure` in production); the session id is regenerated on login.
- Every form carries a **CSRF token**; the `Origin` header is also checked. The JSON API only accepts `application/json`.
- A strict **Content-Security-Policy** (no inline scripts) plus `X-Frame-Options`, `nosniff`, `Referrer-Policy` and HSTS (production).
- Login/registration/password-change attempts are **rate limited** per IP.
- All output is HTML-escaped by EJS; redirects only ever go to paths on this site.
- Public API responses are cached for 15 s; per-user responses are never cached.

## Known limitations (read before deploying)

This is a portfolio/learning project, not production recruitment software.
- **Storage is a single JSON file**, written synchronously. That is fine for a demo and a few users; use a real database (PostgreSQL, MySQL, MongoDB) for anything more.
- **Sessions are kept in memory**: restarting the server signs everyone out, and it cannot run on several servers at once.
- No email verification, password reset by email, file uploads (CV) or third-party sign-in.
- Rate limits and the API cache are per process.

## Troubleshooting

- *`npm.ps1 cannot be loaded` on Windows* → use `npm.cmd install` / `npm.cmd start`, or a Command Prompt terminal.
- *`Port 3000 is already in use`* → set `PORT=3001` in `.env`.
- *Everyone was signed out* → expected after a restart (in-memory sessions).
- *Reset all data* → stop the server and delete `data/store.json`.
