"use strict";
const crypto = require("crypto");
const express = require("express");
const { flash, backTo, wantsJson } = require("../lib/guards");
const { text } = require("../lib/validate");

module.exports = function applications({ store, guards }) {
  const router = express.Router();
  const { requireAuth } = guards;

  router.get("/applications", requireAuth, (req, res) => {
    const list = store.data.applications
      .filter(item => item.userId === req.user.id)
      .map(item => ({ ...item, internship: store.internship(item.internshipId) }))
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    res.render("applications", { applications: list });
  });

  router.post("/apply/:id", requireAuth, (req, res) => {
    const internship = store.internship(req.params.id);
    if (!internship) {
      flash(req, "error", "This opportunity is no longer available.");
      return res.redirect("/");
    }
    if (req.user.role === "admin") {
      flash(req, "info", "Admin accounts can't apply for roles. Use a candidate account.");
      return res.redirect(backTo(req));
    }
    const cover = text(req.body.cover);
    if (cover.length > 600) {
      flash(req, "error", "Your note must be 600 characters or fewer.");
      return res.redirect(backTo(req));
    }
    if (store.data.applications.some(item => item.userId === req.user.id && item.internshipId === internship.id)) {
      flash(req, "info", "You have already applied for this opportunity.");
      return res.redirect("/applications");
    }
    const now = new Date().toISOString();
    store.data.applications.push({
      id: crypto.randomUUID(), userId: req.user.id, internshipId: internship.id,
      cover, status: "Under review", createdAt: now, updatedAt: now
    });
    store.save();
    flash(req, "success", `You have successfully applied for ${internship.title}! You can track your application in My applications.`);
    res.redirect("/applications");
  });

  router.post("/applications/:id/withdraw", requireAuth, (req, res) => {
    const index = store.data.applications.findIndex(item => item.id === req.params.id && item.userId === req.user.id);
    if (index < 0) {
      flash(req, "error", "Application not found.");
      return res.redirect("/applications");
    }
    store.data.applications.splice(index, 1);
    store.save();
    flash(req, "success", "Application withdrawn.");
    res.redirect("/applications");
  });

  router.get("/saved", requireAuth, (req, res) => {
    const ids = store.data.saved.filter(item => item.userId === req.user.id).map(item => item.internshipId);
    res.render("saved", { internships: store.data.internships.filter(item => ids.includes(item.id)), savedIds: ids });
  });

  router.post("/save/:id", requireAuth, (req, res) => {
    const internship = store.internship(req.params.id);
    if (!internship) {
      if (wantsJson(req)) return res.status(404).json({ error: "Opportunity not found." });
      flash(req, "error", "This opportunity is no longer available.");
      return res.redirect("/");
    }
    const index = store.data.saved.findIndex(item => item.userId === req.user.id && item.internshipId === internship.id);
    if (index >= 0) store.data.saved.splice(index, 1);
    else store.data.saved.push({ userId: req.user.id, internshipId: internship.id });
    store.save();
    const saved = index < 0;
    if (wantsJson(req)) return res.json({ saved });
    flash(req, "success", saved ? "Opportunity saved." : "Removed from saved opportunities.");
    res.redirect(backTo(req));
  });

  return router;
};
