"use strict";
const express = require("express");
const { text } = require("../lib/validate");

function boardUrl({ q, category } = {}) {
  const params = new URLSearchParams();
  if (q) params.set("q", q);
  if (category && category !== "All fields") params.set("category", category);
  const query = params.toString();
  return query ? `/?${query}` : "/";
}

module.exports = function pages({ store }) {
  const router = express.Router();

  function board(req, res) {
    const q = text(String(req.query.q || "")).slice(0, 100);
    const needle = q.toLowerCase();
    const allCategories = [...new Set(store.data.internships.map(item => item.category))];
    const requested = text(String(req.query.category || ""));
    const category = allCategories.includes(requested) ? requested : "All fields";

    const internships = store.data.internships
      .filter(item => {
        const haystack = [item.title, item.company, item.category, item.location, item.description, ...(item.skills || [])].join(" ").toLowerCase();
        return (!needle || haystack.includes(needle)) && (category === "All fields" || item.category === category);
      })
      .sort((a, b) => Number(b.featured) - Number(a.featured) || String(b.createdAt).localeCompare(String(a.createdAt)));

    const userId = req.session.userId;
    res.render("home", {
      internships,
      total: store.data.internships.length,
      categories: ["All fields", ...allCategories],
      search: q,
      category,
      boardUrl,
      savedIds: store.data.saved.filter(item => item.userId === userId).map(item => item.internshipId),
      myApplications: store.data.applications.filter(item => item.userId === userId).length
    });
  }

  router.get("/", board);
  router.get("/internships", board);
  return router;
};

module.exports.boardUrl = boardUrl;
