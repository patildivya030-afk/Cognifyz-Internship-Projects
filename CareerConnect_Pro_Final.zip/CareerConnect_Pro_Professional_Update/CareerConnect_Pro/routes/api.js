"use strict";
const crypto = require("crypto");
const express = require("express");
const { STATUSES, parseInternship, text } = require("../lib/validate");

module.exports = function api({ store, guards }) {
  const router = express.Router();
  const { requireAuth, requireAdmin } = guards;

  // Short-lived cache for PUBLIC read endpoints only. Per-user data (applications, saved) is never cached.
  const cache = new Map();
  const TTL = 15 * 1000;
  const publicCache = (req, res, next) => {
    const key = req.originalUrl;
    const hit = cache.get(key);
    if (hit && hit.until > Date.now()) {
      res.set("X-Cache", "HIT");
      return res.json(hit.body);
    }
    const json = res.json.bind(res);
    res.json = body => {
      if (res.statusCode === 200) cache.set(key, { body, until: Date.now() + TTL });
      res.set("X-Cache", "MISS");
      return json(body);
    };
    next();
  };
  const clearCache = () => cache.clear();

  // Private responses must never be stored by browsers or proxies.
  router.use("/api", (req, res, next) => {
    if (!["/internships", "/health"].some(prefix => req.path.startsWith(prefix)) || req.method !== "GET") res.set("Cache-Control", "no-store");
    next();
  });

  // Writes must be JSON. HTML forms on other sites cannot send this content type.
  const requireJson = (req, res, next) => {
    if (["POST", "PUT", "PATCH"].includes(req.method) && !req.is("application/json")) {
      return res.status(415).json({ error: "Send the request body as application/json." });
    }
    next();
  };
  router.use("/api", requireJson);

  router.get("/api/health", (req, res) => res.json({ status: "ok", time: new Date().toISOString() }));

  /* ----- Internships ----- */
  router.get("/api/internships", publicCache, (req, res) => {
    const q = text(String(req.query.q || "")).toLowerCase();
    const category = text(String(req.query.category || ""));
    const featured = req.query.featured === "true";
    const items = store.data.internships.filter(item => {
      const haystack = `${item.title} ${item.company} ${item.category} ${item.location} ${(item.skills || []).join(" ")}`.toLowerCase();
      return (!q || haystack.includes(q)) && (!category || item.category === category) && (!featured || item.featured);
    });
    res.json({ count: items.length, data: items });
  });

  router.get("/api/internships/:id", publicCache, (req, res) => {
    const item = store.internship(req.params.id);
    if (!item) return res.status(404).json({ error: "Opportunity not found." });
    res.json({ data: item });
  });

  router.post("/api/internships", requireAdmin, (req, res) => {
    const { errors, value } = parseInternship(req.body);
    if (Object.keys(errors).length) return res.status(422).json({ error: "Validation failed.", fields: errors });
    const item = { id: `intern-${crypto.randomUUID()}`, ...value, type: "Internship", createdAt: new Date().toISOString() };
    store.data.internships.unshift(item);
    store.save();
    clearCache();
    res.status(201).json({ data: item });
  });

  router.put("/api/internships/:id", requireAdmin, (req, res) => {
    const item = store.internship(req.params.id);
    if (!item) return res.status(404).json({ error: "Opportunity not found." });
    const { errors, value } = parseInternship(req.body, item);
    if (Object.keys(errors).length) return res.status(422).json({ error: "Validation failed.", fields: errors });
    Object.assign(item, value);
    store.save();
    clearCache();
    res.json({ data: item });
  });

  router.delete("/api/internships/:id", requireAdmin, (req, res) => {
    if (!store.removeInternship(req.params.id)) return res.status(404).json({ error: "Opportunity not found." });
    store.save();
    clearCache();
    res.status(204).end();
  });

  /* ----- Applications ----- */
  const publicApplication = item => {
    const user = store.userById(item.userId);
    return { ...item, internship: store.internship(item.internshipId), user: user ? { id: user.id, name: user.name, email: user.email } : null };
  };

  router.get("/api/applications", requireAuth, (req, res) => {
    const data = store.data.applications
      .filter(item => req.user.role === "admin" || item.userId === req.user.id)
      .map(publicApplication);
    res.json({ count: data.length, data });
  });

  router.post("/api/applications", requireAuth, (req, res) => {
    if (req.user.role === "admin") return res.status(403).json({ error: "Admin accounts can't apply for roles." });
    const internship = store.internship(typeof req.body.internshipId === "string" ? req.body.internshipId : "");
    if (!internship) return res.status(404).json({ error: "Opportunity not found." });
    const cover = text(req.body.cover);
    if (cover.length > 600) return res.status(422).json({ error: "Validation failed.", fields: { cover: "Cover note must be 600 characters or fewer." } });
    if (store.data.applications.some(item => item.userId === req.user.id && item.internshipId === internship.id)) {
      return res.status(409).json({ error: "You have already applied." });
    }
    const now = new Date().toISOString();
    const item = { id: crypto.randomUUID(), userId: req.user.id, internshipId: internship.id, cover, status: "Under review", createdAt: now, updatedAt: now };
    store.data.applications.push(item);
    store.save();
    res.status(201).json({ data: publicApplication(item) });
  });

  router.patch("/api/applications/:id", requireAdmin, (req, res) => {
    const item = store.data.applications.find(entry => entry.id === req.params.id);
    if (!item) return res.status(404).json({ error: "Application not found." });
    if (!STATUSES.includes(req.body.status)) return res.status(422).json({ error: "Validation failed.", fields: { status: `Status must be one of: ${STATUSES.join(", ")}.` } });
    item.status = req.body.status;
    item.updatedAt = new Date().toISOString();
    store.save();
    res.json({ data: publicApplication(item) });
  });

  router.delete("/api/applications/:id", requireAuth, (req, res) => {
    const index = store.data.applications.findIndex(entry => entry.id === req.params.id && (req.user.role === "admin" || entry.userId === req.user.id));
    if (index < 0) return res.status(404).json({ error: "Application not found." });
    store.data.applications.splice(index, 1);
    store.save();
    res.status(204).end();
  });

  /* ----- Saved ----- */
  router.get("/api/saved", requireAuth, (req, res) => {
    const data = store.data.saved.filter(item => item.userId === req.user.id).map(item => store.internship(item.internshipId)).filter(Boolean);
    res.json({ count: data.length, data });
  });

  return router;
};
