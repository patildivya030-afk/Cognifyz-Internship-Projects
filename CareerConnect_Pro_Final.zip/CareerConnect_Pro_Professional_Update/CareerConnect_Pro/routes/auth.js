"use strict";
const crypto = require("crypto");
const express = require("express");
const security = require("../lib/security");
const { flash, localPath } = require("../lib/guards");
const { text, oneLine, validEmail, PASSWORD_RULE, PASSWORD_MESSAGE } = require("../lib/validate");

module.exports = function auth({ store, guards, sessions, authLimiter }) {
  const router = express.Router();
  const { requireAuth } = guards;
  const limitedPage = (res, mode, retryAfter, values = {}) => {
    res.set("Retry-After", String(retryAfter));
    return res.status(429).render("auth", {
      mode, errors: { general: `Too many attempts. Please try again in ${Math.ceil(retryAfter / 60)} minute(s).` }, values
    });
  };

  router.get("/register", (req, res) => {
    if (res.locals.currentUser) return res.redirect("/");
    res.render("auth", { mode: "register", errors: {}, values: {} });
  });

  router.post("/register", async (req, res) => {
    const key = `register:${req.ip}`;
    const name = oneLine(req.body.name);
    const email = text(req.body.email).toLowerCase();
    const password = typeof req.body.password === "string" ? req.body.password : "";
    const values = { name, email };

    const limit = authLimiter.status(key);
    if (limit.limited) return limitedPage(res, "register", limit.retryAfter, values);
    authLimiter.hit(key); // every registration attempt counts

    const errors = {};
    if (name.length < 2 || name.length > 60) errors.name = "Enter a name between 2 and 60 characters.";
    if (!validEmail(email)) errors.email = "Enter a valid email address.";
    else if (store.userByEmail(email)) errors.email = "An account with this email already exists.";
    if (!PASSWORD_RULE.test(password)) errors.password = PASSWORD_MESSAGE;
    if (Object.keys(errors).length) return res.status(422).render("auth", { mode: "register", errors, values });

    const user = {
      id: crypto.randomUUID(), name, email,
      passwordHash: await security.hashPassword(password),
      role: "candidate", createdAt: new Date().toISOString()
    };
    // Re-check after the (async) hash in case the same email registered at the same moment.
    if (store.userByEmail(email)) return res.status(422).render("auth", { mode: "register", errors: { email: "An account with this email already exists." }, values });
    store.data.users.push(user);
    store.save();

    req.regenerateSession();
    req.session.userId = user.id;
    flash(req, "success", "Welcome to CareerConnect Pro. Your profile is ready.");
    res.redirect("/");
  });

  router.get("/login", (req, res) => {
    if (res.locals.currentUser) return res.redirect("/");
    res.render("auth", { mode: "login", errors: {}, values: {} });
  });

  router.post("/login", async (req, res) => {
    const email = text(req.body.email).toLowerCase();
    const password = typeof req.body.password === "string" ? req.body.password.slice(0, 256) : "";
    const key = `login:${req.ip}`;

    const limit = authLimiter.status(key);
    if (limit.limited) return limitedPage(res, "login", limit.retryAfter, { email });

    const user = store.userByEmail(email);
    const ok = await security.verifyPassword(password, user && user.passwordHash);
    if (!user || !ok) {
      authLimiter.hit(key); // only failures count
      return res.status(401).render("auth", { mode: "login", errors: { general: "Email or password is incorrect." }, values: { email } });
    }
    authLimiter.clear(key);

    const returnTo = localPath(req.session.returnTo);
    req.regenerateSession();
    req.session.userId = user.id;
    flash(req, "success", `Welcome back, ${user.name.split(" ")[0]}.`);
    res.redirect(returnTo || "/");
  });

  router.post("/logout", (req, res) => {
    req.destroySession();
    res.redirect("/");
  });

  /* ----- Profile ----- */
  router.get("/profile", requireAuth, (req, res) => {
    res.render("profile", {
      applications: store.data.applications.filter(item => item.userId === req.user.id).length,
      saved: store.data.saved.filter(item => item.userId === req.user.id).length,
      errors: {}, values: {}
    });
  });

  const profileView = (req, res, status, errors, values = {}) =>
    res.status(status).render("profile", {
      applications: store.data.applications.filter(item => item.userId === req.user.id).length,
      saved: store.data.saved.filter(item => item.userId === req.user.id).length,
      errors, values
    });

  router.post("/profile/name", requireAuth, (req, res) => {
    const name = oneLine(req.body.name);
    if (name.length < 2 || name.length > 60) return profileView(req, res, 422, { name: "Enter a name between 2 and 60 characters." }, { name });
    req.user.name = name;
    store.save();
    flash(req, "success", "Your name has been updated.");
    res.redirect("/profile");
  });

  router.post("/profile/password", requireAuth, async (req, res) => {
    const key = `password:${req.user.id}`;
    const limit = authLimiter.status(key);
    if (limit.limited) return profileView(req, res, 429, { current: `Too many attempts. Try again in ${Math.ceil(limit.retryAfter / 60)} minute(s).` });

    const current = typeof req.body.current === "string" ? req.body.current.slice(0, 256) : "";
    const next = typeof req.body.password === "string" ? req.body.password : "";
    const errors = {};
    if (!(await security.verifyPassword(current, req.user.passwordHash))) {
      authLimiter.hit(key);
      errors.current = "Your current password is incorrect.";
    }
    if (!PASSWORD_RULE.test(next)) errors.password = PASSWORD_MESSAGE;
    else if (next === current) errors.password = "Choose a password different from your current one.";
    if (Object.keys(errors).length) return profileView(req, res, 422, errors);
    authLimiter.clear(key);

    req.user.passwordHash = await security.hashPassword(next);
    store.save();
    const userId = req.user.id;
    sessions.destroyForUser(userId); // sign out every other device
    req.regenerateSession();
    req.session.userId = userId;
    flash(req, "success", "Password changed. Other devices have been signed out.");
    res.redirect("/profile");
  });

  return router;
};
