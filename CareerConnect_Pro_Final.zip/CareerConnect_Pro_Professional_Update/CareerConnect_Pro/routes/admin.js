"use strict";
const crypto = require("crypto");
const express = require("express");
const { flash } = require("../lib/guards");
const { STATUSES, parseInternship } = require("../lib/validate");

module.exports = function admin({ store, guards }) {
  const router = express.Router();
  const { requireAdmin } = guards;

  router.get("/admin", requireAdmin, (req, res) => {
    const applications = store.data.applications
      .map(item => ({ ...item, user: store.userById(item.userId), internship: store.internship(item.internshipId) }))
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    res.render("admin", {
      internships: store.data.internships,
      applications,
      candidateCount: store.data.users.filter(user => user.role === "candidate").length,
      errors: {}, values: {}
    });
  });

  router.post("/admin/internships", requireAdmin, (req, res) => {
    const { errors, value } = parseInternship(req.body);
    if (Object.keys(errors).length) {
      return res.status(422).render("admin", {
        internships: store.data.internships,
        applications: store.data.applications
          .map(item => ({ ...item, user: store.userById(item.userId), internship: store.internship(item.internshipId) }))
          .sort((a, b) => b.createdAt.localeCompare(a.createdAt)),
        candidateCount: store.data.users.filter(user => user.role === "candidate").length,
        errors, values: req.body
      });
    }
    store.data.internships.unshift({ id: `intern-${crypto.randomUUID()}`, ...value, type: "Internship", createdAt: new Date().toISOString() });
    store.save();
    flash(req, "success", "Opportunity published.");
    res.redirect("/admin");
  });

  router.post("/admin/internships/:id/delete", requireAdmin, (req, res) => {
    if (store.removeInternship(req.params.id)) {
      store.save();
      flash(req, "success", "Opportunity removed.");
    } else {
      flash(req, "error", "Opportunity not found.");
    }
    res.redirect("/admin");
  });

  router.post("/admin/applications/:id/status", requireAdmin, (req, res) => {
    const application = store.data.applications.find(item => item.id === req.params.id);
    const status = typeof req.body.status === "string" ? req.body.status : "";
    if (!application) flash(req, "error", "Application not found.");
    else if (!STATUSES.includes(status)) flash(req, "error", "Choose a valid status.");
    else {
      application.status = status;
      application.updatedAt = new Date().toISOString();
      store.save();
      flash(req, "success", "Application status updated.");
    }
    res.redirect("/admin");
  });

  return router;
};
