"use strict";
const express = require("express");
const path = require("path");
const crypto = require("crypto");

const { Store } = require("./lib/store");
const security = require("./lib/security");
const { createGuards } = require("./lib/guards");
const { formatDate, timeAgo, initials, slug } = require("./lib/format");
const { CATEGORIES, LEVELS, STATUSES, PASSWORD_RULE } = require("./lib/validate");

const DEMO_ADMIN = { email: "admin@careerconnect.demo", password: "Admin@12345" };

async function createApp(options = {}) {
  const production = (options.nodeEnv || process.env.NODE_ENV) === "production";
  let secret = options.secret || process.env.SESSION_SECRET;
  if (production && (!secret || secret.length < 32 || /replace-this/i.test(secret))) {
    throw new Error("SESSION_SECRET must be set to a random value of at least 32 characters when NODE_ENV=production.");
  }
  secret = secret || crypto.randomBytes(32).toString("hex"); // dev: random per run (sessions are in memory anyway)

  const dataFile = options.dataFile || process.env.DATA_FILE || path.join(__dirname, "data", "store.json");
  const store = new Store(dataFile);
  const guards = createGuards(store);
  const sessions = security.createSessions({
    secret,
    secure: options.cookieSecure ?? (process.env.COOKIE_SECURE ? process.env.COOKIE_SECURE === "true" : production)
  });
  const authLimiter = security.createRateLimiter({
    windowMs: options.rateWindowMs || 15 * 60 * 1000,
    max: options.rateLimitMax || Number(process.env.AUTH_RATE_LIMIT) || 10
  });

  // Make sure there is an admin account. In production the credentials must come from the environment.
  const adminEmail = (options.adminEmail || process.env.ADMIN_EMAIL || (production ? "" : DEMO_ADMIN.email)).trim().toLowerCase();
  const adminPassword = options.adminPassword || process.env.ADMIN_PASSWORD || (production ? "" : DEMO_ADMIN.password);
  let demoAdmin = null;
  if (!store.data.users.some(user => user.role === "admin")) {
    if (adminEmail && PASSWORD_RULE.test(adminPassword)) {
      store.data.users.push({
        id: crypto.randomUUID(), name: "CareerConnect Admin", email: adminEmail,
        passwordHash: await security.hashPassword(adminPassword), role: "admin", createdAt: new Date().toISOString()
      });
      store.save();
    } else {
      console.warn("No admin account created. Set ADMIN_EMAIL and a strong ADMIN_PASSWORD to create one.");
    }
  }
  if (!production && adminEmail === DEMO_ADMIN.email && adminPassword === DEMO_ADMIN.password) demoAdmin = DEMO_ADMIN;

  const app = express();
  app.disable("x-powered-by");
  app.set("view engine", "ejs");
  app.set("views", path.join(__dirname, "views"));
  if (process.env.TRUST_PROXY) app.set("trust proxy", process.env.TRUST_PROXY === "true" ? 1 : process.env.TRUST_PROXY);

  app.use(security.securityHeaders({ production }));
  app.use(express.static(path.join(__dirname, "public"), { maxAge: production ? "1h" : 0 }));

  // Safe defaults so error pages can render even if a request fails before the session loads.
  app.use((req, res, next) => {
    Object.assign(res.locals, {
      currentUser: null, flash: null, currentPath: req.path, csrfToken: "", demoAdmin,
      formatDate, timeAgo, initials, slug,
      CATEGORIES, LEVELS, STATUSES
    });
    next();
  });

  app.use(express.urlencoded({ extended: false, limit: "20kb" }));
  app.use(express.json({ limit: "20kb" }));
  app.use((req, res, next) => { req.body = req.body || {}; next(); });
  app.use(sessions);

  app.use((req, res, next) => {
    res.locals.currentUser = store.userById(req.session.userId);
    res.locals.flash = req.session.flash || null;
    delete req.session.flash;
    // Lazily create the CSRF token the first time a page asks for it.
    Object.defineProperty(res.locals, "csrfToken", { configurable: true, enumerable: true, get: () => security.csrfToken(req) });
    next();
  });

  app.use((req, res, next) => {
    const start = Date.now();
    res.on("finish", () => console.log(`${new Date().toISOString()} ${req.method} ${req.originalUrl.split("?")[0]} ${res.statusCode} ${Date.now() - start}ms`));
    next();
  });
  app.use(security.originCheck);
  app.use(security.csrfProtection);

  const ctx = { store, guards, sessions, authLimiter };
  app.use(require("./routes/pages")(ctx));
  app.use(require("./routes/auth")(ctx));
  app.use(require("./routes/applications")(ctx));
  app.use(require("./routes/admin")(ctx));
  app.use(require("./routes/api")(ctx));

  app.use((req, res) => {
    if (req.path.startsWith("/api/")) return res.status(404).json({ error: "Endpoint not found." });
    res.status(404).render("404");
  });

  // eslint-disable-next-line no-unused-vars
  app.use((err, req, res, next) => {
    const status = err.status || err.statusCode || 500;
    if (status >= 500) console.error(err.stack || err);
    const known = {
      400: "That request couldn't be understood.",
      413: "That request was too large.",
      500: "Something went wrong on our side. Please try again."
    };
    const message = status < 500 ? (known[status] || "That request couldn't be processed.") : known[500];
    if (req.path.startsWith("/api/")) return res.status(status).json({ error: message });
    res.status(status).render("error", { status, heading: status < 500 ? "We couldn't process that" : "Something went wrong", message });
  });

  app.store = store;
  app.sessions = sessions;
  return app;
}

module.exports = { createApp, DEMO_ADMIN };
