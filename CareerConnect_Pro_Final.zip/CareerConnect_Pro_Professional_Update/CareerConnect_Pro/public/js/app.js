"use strict";
document.addEventListener("DOMContentLoaded", () => {
  /* ----- Mobile navigation ----- */
  const menu = document.getElementById("mobileMenu");
  const nav = document.getElementById("navLinks");
  if (menu && nav) {
    menu.addEventListener("click", () => {
      const open = nav.classList.toggle("nav-open");
      menu.setAttribute("aria-expanded", String(open));
    });
  }

  /* ----- Toast notifications ----- */
  document.querySelectorAll(".toast").forEach(toast => {
    const dismiss = () => toast.remove();
    const closeButton = toast.querySelector(".toast-close");
    if (closeButton) closeButton.addEventListener("click", dismiss);
    setTimeout(dismiss, 6500);
  });

  /* ----- Confirm dialogs (forms with data-confirm) ----- */
  document.querySelectorAll("form[data-confirm]").forEach(form => {
    form.addEventListener("submit", event => {
      if (!window.confirm(form.dataset.confirm)) event.preventDefault();
    });
  });

  /* ----- Apply modal ----- */
  const modal = document.getElementById("applyModal");
  const applyForm = document.getElementById("applyForm");
  const modalJobTitle = document.getElementById("modalJobTitle");
  const closeButton = document.getElementById("closeModal");
  const cover = document.getElementById("cover");
  const coverCount = document.getElementById("coverCount");
  let lastTrigger = null;

  const closeModal = () => {
    if (!modal) return;
    modal.hidden = true;
    document.body.classList.remove("modal-open");
    if (lastTrigger) lastTrigger.focus();
  };

  if (modal) {
    document.querySelectorAll(".apply-trigger").forEach(button => {
      button.addEventListener("click", () => {
        lastTrigger = button;
        if (applyForm) applyForm.action = `/apply/${encodeURIComponent(button.dataset.jobId)}`;
        if (modalJobTitle) modalJobTitle.textContent = button.dataset.jobTitle || "Selected opportunity";
        if (cover) { cover.value = ""; if (coverCount) coverCount.textContent = "0 / 600"; }
        modal.hidden = false;
        document.body.classList.add("modal-open");
        (cover || closeButton || modal).focus();
      });
    });
    if (closeButton) closeButton.addEventListener("click", closeModal);
    modal.addEventListener("click", event => { if (event.target === modal) closeModal(); });
    document.addEventListener("keydown", event => { if (event.key === "Escape" && !modal.hidden) closeModal(); });
  }
  if (cover && coverCount) cover.addEventListener("input", () => { coverCount.textContent = `${cover.value.length} / 600`; });

  /* ----- Save / unsave without a page reload (falls back to a normal form post) ----- */
  document.querySelectorAll("form.save-form").forEach(form => {
    form.addEventListener("submit", async event => {
      event.preventDefault();
      const button = form.querySelector(".save-button");
      try {
        const response = await fetch(form.action, {
          method: "POST",
          headers: { Accept: "application/json", "Content-Type": "application/x-www-form-urlencoded" },
          body: new URLSearchParams(new FormData(form)).toString()
        });
        if (response.status === 401) { window.location.href = "/login"; return; }
        if (!response.ok) throw new Error("Request failed");
        const { saved } = await response.json();
        if (document.querySelector(".saved-grid") && !saved) {
          const card = form.closest(".job-card");
          if (card) card.remove();
          if (!document.querySelector(".saved-grid .job-card")) window.location.reload();
          return;
        }
        button.classList.toggle("is-saved", saved);
        button.textContent = saved ? "♥" : "♡";
        button.setAttribute("aria-label", `${saved ? "Unsave" : "Save"} opportunity`);
      } catch {
        form.submit(); // let the server handle it the classic way
      }
    }, { once: false });
  });

  /* ----- Password visibility + strength meter ----- */
  const toggle = document.getElementById("togglePassword");
  const password = document.getElementById("password");
  if (toggle && password) {
    toggle.addEventListener("click", () => {
      const reveal = password.type === "password";
      password.type = reveal ? "text" : "password";
      toggle.textContent = reveal ? "Hide" : "Show";
    });
  }
  const meter = document.getElementById("strengthMeter");
  const strengthLabel = document.getElementById("strengthLabel");
  if (password && meter && strengthLabel) {
    const labels = ["Use 8+ characters, upper & lower case, a number and a symbol.", "Needs more variety.", "Getting there — add more variety.", "Almost there — one more type of character.", "Strong password."];
    password.addEventListener("input", () => {
      const value = password.value;
      const score = [value.length >= 8, /[A-Z]/.test(value) && /[a-z]/.test(value), /\d/.test(value), /[^A-Za-z0-9]/.test(value)].filter(Boolean).length;
      [...meter.children].forEach((bar, index) => bar.classList.toggle("filled", index < score));
      strengthLabel.textContent = value ? labels[score] : labels[0];
      strengthLabel.className = `strength-label strength-${score}`;
    });
  }

  /* ----- Inline form validation (server validates again) ----- */
  const authForm = document.getElementById("authForm");
  if (authForm) {
    const isRegister = authForm.getAttribute("action") === "/register";
    const strong = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9]).{8,128}$/;
    const validate = input => {
      const errorEl = input.closest(".form-field")?.querySelector(".field-error");
      const value = input.value.trim();
      let message = "";
      if (!value) message = "This field is required.";
      else if (input.type === "email" && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(value)) message = "Enter a valid email address.";
      else if (input.name === "name" && value.length < 2) message = "Enter at least 2 characters.";
      else if (input.name === "password" && isRegister && !strong.test(input.value)) message = "Use 8+ characters with uppercase, lowercase, number and symbol.";
      input.classList.toggle("input-invalid", Boolean(message));
      if (errorEl) errorEl.textContent = message;
      return !message;
    };
    authForm.querySelectorAll("input[required]").forEach(input => {
      input.addEventListener("blur", () => { if (input.value) validate(input); });
      input.addEventListener("input", () => { if (input.classList.contains("input-invalid")) validate(input); });
    });
    authForm.addEventListener("submit", event => {
      let valid = true;
      authForm.querySelectorAll("input[required]").forEach(input => { if (!validate(input)) valid = false; });
      if (!valid) event.preventDefault();
    });
  }

  /* ----- REST API preview on the home page ----- */
  const apiButton = document.getElementById("apiPreview");
  const apiResult = document.getElementById("apiResult");
  const apiOutput = document.getElementById("apiOutput");
  const closeApi = document.getElementById("closeApi");
  if (apiButton && apiResult && apiOutput) {
    apiButton.addEventListener("click", async () => {
      apiResult.hidden = false;
      apiOutput.textContent = "Requesting /api/internships …";
      try {
        const response = await fetch("/api/internships", { headers: { Accept: "application/json" } });
        const data = await response.json();
        apiOutput.textContent = JSON.stringify({ status: response.status, cache: response.headers.get("X-Cache"), count: data.count, sample: (data.data || []).slice(0, 2) }, null, 2);
      } catch {
        apiOutput.textContent = "Could not reach the API. Check that the server is running.";
      }
    });
  }
  if (closeApi && apiResult) closeApi.addEventListener("click", () => { apiResult.hidden = true; });
});
