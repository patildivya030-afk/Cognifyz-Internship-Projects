# Cognifyz internship task map

One application covers the tasks so the modules share the same data and account flow.
Where something is **not** implemented, this table says so.

| Task | Where it is implemented | Status |
|---|---|---|
| **1 – HTML structure & basic server interaction** | Server-rendered EJS pages (`views/`), Express routes (`routes/`), forms for register / login / apply / publish role | Complete |
| **2 – Styling, interaction & server validation** | Inline field validation and password-strength meter (`public/js/app.js`); server-side validation in `lib/validate.js` and the auth routes; data persisted in `data/store.json` | Complete |
| **3 – Advanced CSS & responsive design** | `public/css/style.css`: CSS variables, grid/flex layouts, mobile navigation, cards, animations, focus states, `prefers-reduced-motion` | Complete |
| **4 – Complex validation & DOM manipulation** | Password rules + live meter, character counter, apply modal, instant save/unsave, API preview panel, filter chips | Complete |
| **5 – API integration** | REST API under `/api/...` (`routes/api.js`); the home page fetches `/api/internships` and the save button calls `/save/:id` with `fetch()` | Complete |
| **6 – Database & authentication** | Registration/login, scrypt password hashes, server-side sessions, candidate/admin roles. **Storage is a JSON file, not MongoDB/MySQL** | Authentication complete; database is file-based |
| **7 – Advanced / third-party API** | Consistent JSON error responses and input validation only. **No external provider or OAuth is integrated** | Not implemented |
| **8 – Server-side functionality** | Middleware pipeline in `app.js`, request logging, rate limiting, CSRF protection, security headers, 15 s cache for public API reads, graceful shutdown, 36 automated tests (`npm test`) | Complete |

Tasks 1–6 and 8 are demonstrated. Task 7 and a real database server are the natural next steps.
