"use strict";
const { test, before, after } = require("node:test");
const assert = require("node:assert/strict");
const fs = require("fs");
const os = require("os");
const path = require("path");
const { createApp } = require("../app");
const security = require("../lib/security");

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "careerconnect-"));
const ADMIN = { email: "admin@careerconnect.demo", password: "Admin@12345" };
const GOOD_PASSWORD = "Strong@1234";
let server, base, silence;

// Minimal browser-like client: keeps cookies, never follows redirects automatically.
class Client {
  constructor() { this.cookies = {}; }
  async request(url, { method = "GET", form, json, headers = {} } = {}) {
    const h = { ...headers };
    const cookie = Object.entries(this.cookies).map(([k, v]) => `${k}=${v}`).join("; ");
    if (cookie) h.cookie = cookie;
    let body;
    if (json !== undefined) { h["content-type"] = "application/json"; body = JSON.stringify(json); }
    else if (form) { h["content-type"] = "application/x-www-form-urlencoded"; body = new URLSearchParams(form).toString(); }
    const res = await fetch(base + url, { method, headers: h, body, redirect: "manual" });
    for (const line of res.headers.getSetCookie()) {
      const [pair] = line.split(";");
      const i = pair.indexOf("=");
      const name = pair.slice(0, i), value = pair.slice(i + 1);
      if (/Max-Age=0/i.test(line)) delete this.cookies[name]; else this.cookies[name] = value;
    }
    return res;
  }
  async token(url = "/login") {
    const html = await (await this.request(url)).text();
    return html.match(/name="_csrf" value="([^"]+)"/)[1];
  }
  // POST a form including a valid CSRF token (fetched from `from`).
  async post(url, fields = {}, from = "/login") {
    return this.request(url, { method: "POST", form: { _csrf: await this.token(from), ...fields } });
  }
  async login(email, password) {
    const res = await this.post("/login", { email, password });
    assert.equal(res.status, 302, "login should redirect");
    return res;
  }
}

let counter = 0;
async function newCandidate() {
  const client = new Client();
  const email = `user${++counter}@example.com`;
  const res = await client.post("/register", { name: "Test User", email, password: GOOD_PASSWORD }, "/register");
  assert.equal(res.status, 302);
  return { client, email };
}
async function adminClient() {
  const client = new Client();
  await client.login(ADMIN.email, ADMIN.password);
  return client;
}

before(async () => {
  silence = console.log; console.log = () => {};
  const app = await createApp({ dataFile: path.join(tmp, "store.json"), secret: "x".repeat(40), rateLimitMax: 1000 });
  server = app.listen(0);
  await new Promise(resolve => server.once("listening", resolve));
  base = `http://127.0.0.1:${server.address().port}`;
});
after(() => { console.log = silence; server.close(); fs.rmSync(tmp, { recursive: true, force: true }); });

/* ---------------- Public pages ---------------- */
test("home page renders seeded roles, stats and no template errors", async () => {
  const res = await new Client().request("/");
  const html = await res.text();
  assert.equal(res.status, 200);
  assert.match(html, /Full Stack Developer Intern/);
  assert.match(html, /9<\/b> opportunities/);
  assert.doesNotMatch(html, /undefined|\[object Object\]/);
});

test("search and category filters work and survive each other", async () => {
  const c = new Client();
  let html = await (await c.request("/?q=java")).text();
  assert.match(html, /Java Software Engineer Intern/);
  assert.doesNotMatch(html, /Digital Marketing Intern/);
  html = await (await c.request("/internships?category=Design")).text();
  assert.match(html, /UI\/UX Design Intern/);
  assert.doesNotMatch(html, /Java Software Engineer Intern/);
  html = await (await c.request("/?q=zzzznothing")).text();
  assert.match(html, /No roles match those filters/);
  html = await (await c.request("/?q=python&category=Data%20%26%20AI")).text();
  assert.match(html, /q=python&amp;category=Data/); // chips keep the search term
});

test("search input is escaped (no reflected XSS)", async () => {
  const html = await (await new Client().request('/?q=%22%3E%3Cscript%3Ealert(1)%3C/script%3E')).text();
  assert.doesNotMatch(html, /<script>alert\(1\)/);
});

test("unknown page gives a styled 404", async () => {
  const res = await new Client().request("/nope");
  assert.equal(res.status, 404);
  assert.match(await res.text(), /different path/);
});

test("security headers are present and x-powered-by is hidden", async () => {
  const res = await new Client().request("/");
  assert.match(res.headers.get("content-security-policy"), /script-src 'self'/);
  assert.equal(res.headers.get("x-frame-options"), "DENY");
  assert.equal(res.headers.get("x-content-type-options"), "nosniff");
  assert.equal(res.headers.get("x-powered-by"), null);
});

test("pages ship no inline scripts or handlers (CSP-safe)", async () => {
  const c = new Client();
  for (const url of ["/", "/login", "/register"]) {
    const html = await (await c.request(url)).text();
    assert.doesNotMatch(html, /<script(?![^>]*\bsrc=)/i, url);
    assert.doesNotMatch(html, /\son(click|submit|load|error)=/i, url);
  }
});

test("static assets are served", async () => {
  const c = new Client();
  assert.equal((await c.request("/css/style.css")).status, 200);
  assert.equal((await c.request("/js/app.js")).status, 200);
});

/* ---------------- Auth ---------------- */
test("registration validates input and never stores plaintext passwords", async () => {
  const c = new Client();
  let res = await c.post("/register", { name: "A", email: "bad", password: "weak" }, "/register");
  assert.equal(res.status, 422);
  const html = await res.text();
  assert.match(html, /between 2 and 60/);
  assert.match(html, /valid email/);
  assert.match(html, /8\+ characters/);

  const { email } = await newCandidate();
  const file = JSON.parse(fs.readFileSync(path.join(tmp, "store.json"), "utf8"));
  const user = file.users.find(u => u.email === email);
  assert.ok(user.passwordHash.startsWith("scrypt$"));
  assert.ok(!JSON.stringify(file).includes(GOOD_PASSWORD));
});

test("duplicate email is rejected (case-insensitive)", async () => {
  const { email } = await newCandidate();
  const res = await new Client().post("/register", { name: "Dup", email: email.toUpperCase(), password: GOOD_PASSWORD }, "/register");
  assert.equal(res.status, 422);
  assert.match(await res.text(), /already exists/);
});

test("login: wrong password fails, right password works, session grants access", async () => {
  const { email } = await newCandidate();
  const c = new Client();
  let res = await c.post("/login", { email, password: "Wrong@1234" });
  assert.equal(res.status, 401);
  assert.match(await res.text(), /incorrect/);
  res = await c.post("/login", { email: "nobody@example.com", password: "Wrong@1234" });
  assert.equal(res.status, 401);

  await c.login(email, GOOD_PASSWORD);
  res = await c.request("/applications");
  assert.equal(res.status, 200);
});

test("protected pages redirect anonymous users, and login returns them to the page", async () => {
  const { email } = await newCandidate();
  const c = new Client();
  for (const url of ["/applications", "/saved", "/profile", "/admin"]) {
    const res = await c.request(url);
    assert.equal(res.status, 302, url);
    assert.equal(res.headers.get("location"), "/login", url);
    await res.text();
  }
  await c.request("/saved"); // remembers where we were headed
  const res = await c.post("/login", { email, password: GOOD_PASSWORD });
  assert.equal(res.headers.get("location"), "/saved");
});

test("login never redirects to another site", async () => {
  const { email } = await newCandidate();
  const c = new Client();
  await c.request("/login");
  const res = await c.post("/login", { email, password: GOOD_PASSWORD });
  assert.equal(res.headers.get("location"), "/");
});

test("logout ends the session", async () => {
  const { client } = await newCandidate();
  assert.equal((await client.request("/profile")).status, 200);
  const res = await client.post("/logout", {}, "/profile");
  assert.equal(res.status, 302);
  assert.equal((await client.request("/profile")).status, 302);
});

test("CSRF: posting without a token is blocked", async () => {
  const c = new Client();
  await c.request("/login");
  const res = await c.request("/login", { method: "POST", form: { email: ADMIN.email, password: ADMIN.password } });
  assert.equal(res.status, 403);
  assert.equal((await new Client().request("/login", { method: "POST", form: { email: ADMIN.email, password: ADMIN.password } })).status, 403);
});

test("cross-site Origin is blocked even for JSON", async () => {
  const res = await new Client().request("/api/internships", { method: "POST", json: {}, headers: { origin: "https://evil.example" } });
  assert.equal(res.status, 403);
});

test("login rate limiting kicks in after repeated failures", async () => {
  const app = await createApp({ dataFile: path.join(tmp, "limit.json"), secret: "y".repeat(40), rateLimitMax: 3 });
  const s = app.listen(0);
  await new Promise(r => s.once("listening", r));
  const prev = base; base = `http://127.0.0.1:${s.address().port}`;
  try {
    const c = new Client();
    const statuses = [];
    for (let i = 0; i < 5; i++) statuses.push((await c.post("/login", { email: "x@example.com", password: "Wrong@1234" })).status);
    assert.deepEqual(statuses, [401, 401, 401, 429, 429]);
  } finally { base = prev; s.close(); }
});

test("profile: rename and change password (old password stops working)", async () => {
  const { client, email } = await newCandidate();
  let res = await client.post("/profile/name", { name: "Renamed Person" }, "/profile");
  assert.equal(res.status, 302);
  assert.match(await (await client.request("/profile")).text(), /Renamed Person/);

  res = await client.post("/profile/password", { current: "Wrong@1234", password: "Newer@12345" }, "/profile");
  assert.equal(res.status, 422);
  res = await client.post("/profile/password", { current: GOOD_PASSWORD, password: "weak" }, "/profile");
  assert.equal(res.status, 422);
  res = await client.post("/profile/password", { current: GOOD_PASSWORD, password: "Newer@12345" }, "/profile");
  assert.equal(res.status, 302);

  assert.equal((await new Client().post("/login", { email, password: GOOD_PASSWORD })).status, 401);
  await new Client().login(email, "Newer@12345");
});

test("changing a password signs out the account's other sessions", async () => {
  const { client, email } = await newCandidate();
  const other = new Client();
  await other.login(email, GOOD_PASSWORD);
  assert.equal((await other.request("/profile")).status, 200);
  await client.post("/profile/password", { current: GOOD_PASSWORD, password: "Newer@12345" }, "/profile");
  assert.equal((await other.request("/profile")).status, 302);
});

/* ---------------- Applications & saved ---------------- */
test("apply, duplicate apply, view and withdraw", async () => {
  const { client } = await newCandidate();
  let res = await client.post("/apply/intern-101", { cover: "I love building things." }, "/");
  assert.equal(res.status, 302);
  assert.equal(res.headers.get("location"), "/applications");

  let html = await (await client.request("/applications")).text();
  assert.match(html, /Full Stack Developer Intern/);
  assert.match(html, /I love building things/);
  assert.match(html, /Under review/);

  res = await client.post("/apply/intern-101", {}, "/");
  html = await (await client.request(res.headers.get("location"))).text();
  assert.match(html, /already applied/);

  const id = html.match(/\/applications\/([0-9a-f-]{36})\/withdraw/)[1];
  res = await client.post(`/applications/${id}/withdraw`, {}, "/applications");
  assert.equal(res.status, 302);
  assert.match(await (await client.request("/applications")).text(), /Your next step starts with one application/);
});

test("apply validates the role and the note length", async () => {
  const { client } = await newCandidate();
  let res = await client.post("/apply/does-not-exist", {}, "/");
  assert.equal(res.status, 302);
  assert.match(await (await client.request("/")).text(), /no longer available/);
  res = await client.post("/apply/intern-102", { cover: "x".repeat(601) }, "/");
  assert.equal(res.status, 302);
  assert.match(await (await client.request("/")).text(), /600 characters/);
  assert.match(await (await client.request("/applications")).text(), /Your next step starts/);
});

test("anonymous users cannot apply or save", async () => {
  const c = new Client();
  let res = await c.post("/apply/intern-101", {}, "/login");
  assert.equal(res.status, 302);
  assert.equal(res.headers.get("location"), "/login");
  res = await c.post("/save/intern-101", {}, "/login");
  assert.equal(res.headers.get("location"), "/login");
  // and without any token at all the request is rejected outright
  assert.equal((await new Client().request("/apply/intern-101", { method: "POST", form: {} })).status, 403);
});

test("save toggles, supports JSON, and appears on the saved page", async () => {
  const { client } = await newCandidate();
  const token = await client.token("/");
  let res = await client.request("/save/intern-103", { method: "POST", form: { _csrf: token }, headers: { accept: "application/json" } });
  assert.deepEqual(await res.json(), { saved: true });
  assert.match(await (await client.request("/saved")).text(), /AI \/ Machine Learning Intern/);
  assert.match(await (await client.request("/")).text(), /is-saved/);
  res = await client.request("/save/intern-103", { method: "POST", form: { _csrf: token }, headers: { accept: "application/json" } });
  assert.deepEqual(await res.json(), { saved: false });
  assert.match(await (await client.request("/saved")).text(), /Keep the good ones close/);
  res = await client.request("/save/nope", { method: "POST", form: { _csrf: token }, headers: { accept: "application/json" } });
  assert.equal(res.status, 404);
});

test("save redirect ignores a hostile Referer", async () => {
  const { client } = await newCandidate();
  const res = await client.request("/save/intern-101", { method: "POST", form: { _csrf: await client.token("/") }, headers: { referer: "https://evil.example/phish" } });
  assert.equal(res.headers.get("location"), "/");
});

/* ---------------- Admin ---------------- */
test("candidates are kept out of the admin area", async () => {
  const { client } = await newCandidate();
  const res = await client.request("/admin");
  assert.equal(res.status, 302);
  assert.equal(res.headers.get("location"), "/");
  const post = await client.post("/admin/internships", { title: "Hack" }, "/");
  assert.equal(post.status, 302);
});

test("admin publishes, validates, updates application status and deletes (cascade)", async () => {
  const admin = await adminClient();
  assert.equal((await admin.request("/admin")).status, 200);

  let res = await admin.post("/admin/internships", { title: "", company: "X", category: "Nope" }, "/admin");
  assert.equal(res.status, 422);
  const bad = await res.text();
  assert.match(bad, /Title is required/);
  assert.match(bad, /valid category/);

  res = await admin.post("/admin/internships", {
    title: "QA Automation Intern", company: "TestCo", category: "Engineering", location: "Pune",
    stipend: "₹10,000 / month", duration: "3 months", skills: "Cypress, JS, Cypress, CI",
    description: "Write automated tests that keep releases safe and fast.", level: "Beginner friendly", featured: "on"
  }, "/admin");
  assert.equal(res.status, 302);
  let html = await (await new Client().request("/")).text();
  assert.match(html, /QA Automation Intern/);
  const id = (await (await new Client().request("/api/internships?q=QA%20Automation")).json()).data[0].id;

  const { client, email } = await newCandidate();
  await client.post(`/apply/${id}`, { cover: "Hi" }, "/");
  await client.request(`/save/${id}`, { method: "POST", form: { _csrf: await client.token("/") } });

  html = await (await admin.request("/admin")).text();
  assert.match(html, new RegExp(email.replace(".", "\\.")));
  const appId = html.match(/\/admin\/applications\/([0-9a-f-]{36})\/status/)[1];
  res = await admin.post(`/admin/applications/${appId}/status`, { status: "Shortlisted" }, "/admin");
  assert.equal(res.status, 302);
  assert.match(await (await client.request("/applications")).text(), /Shortlisted/);
  await admin.post(`/admin/applications/${appId}/status`, { status: "Hacked" }, "/admin");
  assert.match(await (await client.request("/applications")).text(), /Shortlisted/);

  await admin.post(`/admin/internships/${id}/delete`, {}, "/admin");
  assert.doesNotMatch(await (await new Client().request("/")).text(), /QA Automation Intern/);
  assert.match(await (await client.request("/applications")).text(), /Your next step starts/);
  assert.match(await (await client.request("/saved")).text(), /Keep the good ones close/);
});

test("admin accounts cannot apply for roles", async () => {
  const admin = await adminClient();
  const res = await admin.post("/apply/intern-101", {}, "/");
  assert.equal(res.status, 302);
  assert.match(await (await admin.request("/")).text(), /can.t apply/);
});

/* ---------------- REST API ---------------- */
test("API: public list/detail/filter with caching headers", async () => {
  const c = new Client();
  let res = await c.request("/api/internships");
  const first = await res.json();
  assert.equal(res.status, 200);
  assert.equal(first.count, first.data.length);
  assert.ok(first.count >= 9);
  assert.equal(res.headers.get("x-cache"), "MISS");
  assert.equal((await c.request("/api/internships")).headers.get("x-cache"), "HIT");

  const filtered = await (await c.request("/api/internships?category=Design")).json();
  assert.ok(filtered.data.every(i => i.category === "Design"));
  assert.equal((await (await c.request("/api/internships?featured=true")).json()).data.every(i => i.featured), true);

  res = await c.request("/api/internships/intern-101");
  assert.equal((await res.json()).data.company, "NexaWorks");
  assert.equal((await c.request("/api/internships/missing")).status, 404);
});

test("API: private data is never shared between users via the cache", async () => {
  const a = await newCandidate();
  const b = await newCandidate();
  await a.client.request("/api/applications", { method: "POST", json: { internshipId: "intern-104", cover: "mine" } });
  const mine = await (await a.client.request("/api/applications")).json();
  assert.equal(mine.count, 1);
  const res = await b.client.request("/api/applications");
  assert.equal(res.headers.get("cache-control"), "no-store");
  assert.equal((await res.json()).count, 0);
});

test("API: authentication and authorisation", async () => {
  const anon = new Client();
  assert.equal((await anon.request("/api/applications")).status, 401);
  assert.equal((await anon.request("/api/internships", { method: "POST", json: {} })).status, 401);
  const { client } = await newCandidate();
  assert.equal((await client.request("/api/internships", { method: "POST", json: {} })).status, 403);
  assert.equal((await client.request("/api/internships/intern-101", { method: "DELETE" })).status, 403);
});

test("API: admin CRUD with validation", async () => {
  const admin = await adminClient();
  let res = await admin.request("/api/internships", { method: "POST", json: { title: "T" } });
  assert.equal(res.status, 422);
  assert.ok((await res.json()).fields.company);

  res = await admin.request("/api/internships", { method: "POST", json: {
    title: "API Intern", company: "ApiCo", category: "Business", location: "Remote", stipend: "₹8,000 / month",
    duration: "2 months", description: "Learn how to build products with APIs and data.", skills: ["REST", "JSON"]
  } });
  assert.equal(res.status, 201);
  const created = (await res.json()).data;
  assert.deepEqual(created.skills, ["REST", "JSON"]);

  // list cache must be invalidated by the write
  assert.ok((await (await new Client().request("/api/internships?q=API%20Intern")).json()).data.some(i => i.id === created.id));

  res = await admin.request(`/api/internships/${created.id}`, { method: "PUT", json: { title: "API Intern II", featured: true } });
  const updated = (await res.json()).data;
  assert.equal(updated.title, "API Intern II");
  assert.equal(updated.company, "ApiCo");
  assert.equal(updated.featured, true);
  assert.deepEqual(updated.skills, ["REST", "JSON"]);

  res = await admin.request(`/api/internships/${created.id}`, { method: "PUT", json: { category: "Bogus" } });
  assert.equal(res.status, 422);

  assert.equal((await admin.request(`/api/internships/${created.id}`, { method: "DELETE" })).status, 204);
  assert.equal((await admin.request(`/api/internships/${created.id}`, { method: "DELETE" })).status, 404);
  assert.equal((await new Client().request(`/api/internships/${created.id}`)).status, 404);
});

test("API: applications create/duplicate/patch/delete", async () => {
  const { client } = await newCandidate();
  let res = await client.request("/api/applications", { method: "POST", json: { internshipId: "nope" } });
  assert.equal(res.status, 404);
  res = await client.request("/api/applications", { method: "POST", json: { internshipId: "intern-105", cover: "x".repeat(601) } });
  assert.equal(res.status, 422);
  res = await client.request("/api/applications", { method: "POST", json: { internshipId: "intern-105", cover: "hello" } });
  assert.equal(res.status, 201);
  const app = (await res.json()).data;
  assert.equal(app.status, "Under review");
  assert.equal((await client.request("/api/applications", { method: "POST", json: { internshipId: "intern-105" } })).status, 409);

  assert.equal((await client.request(`/api/applications/${app.id}`, { method: "PATCH", json: { status: "Offer extended" } })).status, 403);
  const admin = await adminClient();
  res = await admin.request(`/api/applications/${app.id}`, { method: "PATCH", json: { status: "Offer extended" } });
  assert.equal((await res.json()).data.status, "Offer extended");
  assert.equal((await admin.request(`/api/applications/${app.id}`, { method: "PATCH", json: { status: "Nope" } })).status, 422);
  assert.ok((await (await admin.request("/api/applications")).json()).count >= 1);

  assert.equal((await client.request(`/api/applications/${app.id}`, { method: "DELETE" })).status, 204);
  assert.equal((await client.request(`/api/applications/${app.id}`, { method: "DELETE" })).status, 404);
});

test("API: saved list, health, malformed JSON, wrong content type, unknown route", async () => {
  const { client } = await newCandidate();
  await client.request("/save/intern-106", { method: "POST", form: { _csrf: await client.token("/") } });
  const saved = await (await client.request("/api/saved")).json();
  assert.equal(saved.count, 1);
  assert.equal(saved.data[0].id, "intern-106");

  assert.equal((await (await new Client().request("/api/health")).json()).status, "ok");

  let res = await client.request("/api/applications", { method: "POST", headers: { "content-type": "application/json" }, form: undefined, json: undefined });
  assert.ok([400, 415, 404, 422].includes(res.status));
  res = await fetch(base + "/api/applications", { method: "POST", headers: { "content-type": "application/json", cookie: Object.entries(client.cookies).map(([k, v]) => `${k}=${v}`).join("; ") }, body: "{bad json" });
  assert.equal(res.status, 400);
  assert.equal((await res.json()).error, "That request couldn't be understood.");
  res = await client.request("/api/applications", { method: "POST", form: { internshipId: "intern-101" } });
  assert.equal(res.status, 415);
  assert.equal((await new Client().request("/api/unknown")).status, 404);
});

test("data persists to disk and reloads", async () => {
  const file = path.join(tmp, "persist.json");
  const first = await createApp({ dataFile: file, secret: "z".repeat(40) });
  first.store.data.users.push({ id: "u1", name: "Persisted", email: "p@example.com", passwordHash: "x", role: "candidate", createdAt: new Date().toISOString() });
  first.store.save();
  const second = await createApp({ dataFile: file, secret: "z".repeat(40) });
  assert.ok(second.store.userByEmail("p@example.com"));
  assert.equal(second.store.data.users.filter(u => u.role === "admin").length, 1);
});

test("a corrupted data file is backed up instead of crashing", async () => {
  const file = path.join(tmp, "corrupt.json");
  fs.writeFileSync(file, "{ not json");
  const app = await createApp({ dataFile: file, secret: "c".repeat(40) });
  assert.ok(app.store.data.internships.length >= 9);
  assert.ok(fs.readdirSync(tmp).some(name => name.startsWith("corrupt.json.corrupt-")));
});

test("production refuses to start without a strong secret and hides demo credentials", async () => {
  await assert.rejects(() => createApp({ dataFile: path.join(tmp, "p1.json"), nodeEnv: "production", secret: "short" }), /SESSION_SECRET/);
  const app = await createApp({ dataFile: path.join(tmp, "p2.json"), nodeEnv: "production", secret: "s".repeat(40) });
  assert.equal(app.store.data.users.length, 0); // no default admin in production
});

test("session store is capped so bots can't exhaust memory", () => {
  const sessions = security.createSessions({ secret: "k".repeat(32), maxSessions: 3 });
  for (let i = 0; i < 10; i++) {
    const req = { headers: {} };
    const res = { writeHead() {}, append() {} };
    sessions(req, res, () => {});
    req.session.visit = i;
    res.writeHead(200);
  }
  assert.equal(sessions.size(), 3);
});
